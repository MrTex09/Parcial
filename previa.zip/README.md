En este proyecto te encontraras 4 paginas

home

un header que contiene enlaces a las otras tres paginas
un descripcion breve de mi
un footer que contiene un copyright y links a contacto y trabajo

trabajos

un header que contiene enlaces a las otras tres paginas
contiene 3 card con"trbajos/proyectos" "mios"
un footer con copyright y links a contacto y trabajo


sobre mi

un header que contiene enlaces a las otras tres paginas
y una descripcion detallada sobre mi
un footer que contiene  con copyright  y links a contacto y trabajo


contacto

un header que contiene enlaces a las otras tres paginas
3 card que contienen enlaces a gmail mi github y mis projectos
un footer que contiene un copyright y links a contacto y trabajo

